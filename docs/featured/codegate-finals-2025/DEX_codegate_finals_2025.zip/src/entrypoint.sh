#!/bin/bash

for f in /startup/*; do
    echo "[+] running $f"
    bash "$f"
done

tail -f /var/log/ctf/gunicorn.error.log
# tail -f /var/log/ctf/e
# tail -f /var/log/ctf/xinetd.log