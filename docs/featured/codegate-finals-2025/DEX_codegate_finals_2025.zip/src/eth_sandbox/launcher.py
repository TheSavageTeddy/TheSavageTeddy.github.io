import hashlib
import json
import os
import random
import time
from dataclasses import dataclass
from typing import Callable, NoReturn
from uuid import UUID
from threading import Thread, Timer
from pathlib import Path

import requests
from eth_account import Account
from eth_account.signers.local import LocalAccount
from eth_sandbox.auth import get_shared_secret
from web3 import Web3
from web3.exceptions import TransactionNotFound
from web3.types import TxParams, TxReceipt, Wei

HTTP_PORT = os.getenv("HTTP_PORT", "8545")
PUBLIC_IP = os.getenv("PUBLIC_IP", "127.0.0.1")
TIMEOUT = int(os.getenv("TIMEOUT", "60"))

ENV = os.getenv("ENV", "production")
FLAG = os.getenv("FLAG", "FLAG{placeholder}")
FUNC_SIG_IS_SOLVED = os.getenv("FUNC_SIG_IS_SOLVED", "isSolved()")
CODE_CHAIN = 10
GATE_CHAIN = 100

Account.enable_unaudited_hdwallet_features()


def check_uuid(uuid: str) -> str | None:
    try:
        UUID(uuid)
        return uuid
    except (TypeError, ValueError):
        return None


@dataclass
class Action:
    name: str
    handler: Callable[[], int]


def send_transaction(
    web3: Web3, tx: TxParams, ignore_status: bool = False
) -> TxReceipt | None:
    if "gas" not in tx:
        tx["gas"] = 20_000_000

    # if "gasPrice" not in tx:
    #     tx["gasPrice"] = Wei(1)

    txhash = web3.eth.send_transaction(tx)

    while True:
        try:
            rcpt = web3.eth.get_transaction_receipt(txhash)
            break
        except TransactionNotFound:
            time.sleep(0.1)

    if (not ignore_status) and rcpt["status"] != 1:
        raise Exception("failed to send transaction")

    return rcpt


def new_launch_instance_action(
    do_deploy: Callable[[Web3, str, str, str, int], str],
) -> Action:
    def action() -> int:
        pow_request(24) if ENV == "production" else print("skipping pow for testing")

        print("deploying your private blockchain... (~60 seconds)")

        data = requests.post(
            f"http://127.0.0.1:{HTTP_PORT}/new",
            headers={
                "Authorization": f"Bearer {get_shared_secret()}",
                "Content-Type": "application/json",
            },
        ).json()

        if not data["ok"]:
            print(data["message"])
            return 1

        node_info = data["node_info"]
        node_id = data["node_id"]
        player_accounts = []
        setup_addrs = []

        for i, node in enumerate(node_info):
            uuid = node["uuid"]
            mnemonic = node["mnemonic"]

            deployer_account: LocalAccount = Account.from_mnemonic(
                mnemonic, account_path="m/44'/60'/0'/0/0"
            )

            faucet_account: LocalAccount = Account.from_mnemonic(
                mnemonic, account_path="m/44'/60'/0'/0/1"
            )

            player_account: LocalAccount = Account.from_mnemonic(
                mnemonic, account_path="m/44'/60'/0'/0/2"
            )

            player_accounts.append(player_account)

            web3 = Web3(
                Web3.HTTPProvider(
                    f"http://127.0.0.1:{HTTP_PORT}/{uuid}",
                    request_kwargs={
                        "headers": {
                            "Authorization": f"Bearer {get_shared_secret()}",
                            "Content-Type": "application/json",
                        },
                    },
                )
            )

            setup_addr = do_deploy(web3, deployer_account.address, faucet_account.address, player_account.address, i)
            setup_addrs.append(setup_addr)

            setup_abi = json.loads(Path("/home/ctf/compiled/Setup.sol/Setup.json").read_text())["abi"]
            setup_contract = web3.eth.contract(address=setup_addr, abi=setup_abi)
            faucet_logic_addr = setup_contract.functions.faucetLogic().call()
            signed_auth = faucet_account.sign_authorization({
                "chainId": 0, 
                "address": faucet_logic_addr,
                "nonce": 0
            })

            nonce = web3.eth.get_transaction_count(deployer_account.address)
            tx_dict = {
                "chainId": CODE_CHAIN if i==0 else GATE_CHAIN,
                "to": setup_addr,
                "data": setup_contract.encode_abi("getToken", []),
                "nonce": nonce,
                "gas": Wei(1_000_000),
                "maxFeePerGas": Wei(10_000_000_000),
                "maxPriorityFeePerGas": Wei(0),
            }
            if i == 0: ## CODE chain only
                tx_dict["authorizationList"] = [signed_auth]
            signed_tx = deployer_account.sign_transaction(tx_dict)
            tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
            tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash)
            
            with open(f"/tmp/deploy-info/{uuid}", "w") as f:
                f.write(
                    json.dumps(
                        {
                            "uuid": uuid,
                            "mnemonic": mnemonic,
                            "address": setup_addr,
                        }
                    )
                )


        with open(f"/tmp/deploy-info/{node_id}", "w") as f:
            f.write(
                json.dumps(
                    {
                        "uuids": [node_info[0]["uuid"], node_info[1]["uuid"]]
                    }
                )
            )

        print()
        print("your private blockchain has been deployed")
        print(f"it will automatically terminate in {TIMEOUT} seconds")
        print("here's some useful information")
        print(f"uuid:               {node_id}")
        print(f"CODE chain endpoint: http://{PUBLIC_IP}:{HTTP_PORT}/{node_info[0]['uuid']}")
        print(f"GATE chain endpoint: http://{PUBLIC_IP}:{HTTP_PORT}/{node_info[1]['uuid']}")
        print()
        print(f"CODE chain private key: {player_accounts[0].key.hex()}")
        print(f"CODE chain address:    {player_accounts[0].address}")
        print()
        print(f"GATE chain private key: {player_accounts[1].key.hex()}")
        print(f"GATE chain address:    {player_accounts[1].address}")
        print()
        print(f"CODE chain setup address: {setup_addrs[0]}")
        print(f"GATE chain setup address: {setup_addrs[1]}")
        print()
        print(f"CODE chain-id: {CODE_CHAIN}")
        print(f"GATE chain-id: {GATE_CHAIN}")
        
        return 0

    return Action(name="launch new instance", handler=action)

def new_kill_instance_action() -> Action:
    def action() -> int:
        try:
            uuid = check_uuid(input("uuid please: "))
            if not uuid:
                print("invalid uuid!")
                return 1
        except Exception as e:
            print(f"Error with UUID: {e}")
            return 1

        data = requests.post(
            f"http://127.0.0.1:{HTTP_PORT}/kill",
            headers={
                "Authorization": f"Bearer {get_shared_secret()}",
                "Content-Type": "application/json",
            },
            data=json.dumps(
                {
                    "uuid": uuid,
                }
            ),
        ).json()

        print(data["message"])
        return 0

    return Action(name="kill instance", handler=action)


def is_solved_checker(web3: Web3, addr: str) -> bool:
    result = web3.eth.call(
        {
            "to": addr,
            "data": web3.keccak(text=FUNC_SIG_IS_SOLVED)[:4],
        }
    )
    return int(result.hex(), 16) == 1


def new_get_flag_action(
    checker: Callable[[Web3, str], bool] = is_solved_checker,
) -> Action:
    def action() -> int:
        try:
            uuid = check_uuid(input("uuid please: "))
            if not uuid:
                print("invalid uuid!")
                return 1
        except Exception as e:
            print(f"Error with UUID: {e}")
            return 1
        try:
            with open(f"/tmp/deploy-info/{uuid}", "r") as f:
                uuids = json.loads(f.read())["uuids"]
        except Exception:
            print('bad uuid')
            return 1

        ## check flag on the CODE chain
        code_uuid = uuids[0]
        with open(f"/tmp/deploy-info/{code_uuid}", "r") as f:
            data = json.loads(f.read())

        web3 = Web3(Web3.HTTPProvider(f"http://127.0.0.1:{HTTP_PORT}/{data['uuid']}"))

        try:
            if not checker(web3, data["address"]):
                print("are you sure you solved it?")
                return 1
        except Exception as e:
            print(f"Error with checker: {e}")
            return 1

        print()
        print("Congratulations! You have solved it! Here's the flag: ")
        print(FLAG)
        return 0

    return Action(
        name=f"get flag (if {FUNC_SIG_IS_SOLVED} is true)",
        handler=action,
    )


def pow_request(bits: int = 24) -> None:
    SOLVE_POW_PY_URL = f"http://{PUBLIC_IP}:{HTTP_PORT}/pow"
    preimage_prefix = hex(random.randint(0, 1 << 64))[2:]

    print()
    print("== PoW ==")
    print(
        f'  sha256("{preimage_prefix}" + YOUR_INPUT) must start with {bits} zeros in binary representation'
    )
    print("  please run the following command to solve it:")
    print(f"    python3 <(curl -sSL {SOLVE_POW_PY_URL}) {preimage_prefix} {bits}")
    print()
    your_input = input("  YOUR_INPUT = ")
    print()
    if len(your_input) > 0x100:
        print("  your_input must be less than 256 bytes")
        exit(1)

    digest = hashlib.sha256((preimage_prefix + your_input).encode()).digest()
    digest_int = int.from_bytes(digest, "big")
    print(f'  sha256("{preimage_prefix + your_input}") = {digest.hex()}')
    if digest_int < (1 << (256 - bits)):
        print("  correct")
    else:
        print("  incorrect")
        exit(1)
    print("== END POW ==")


def run_launcher(actions: list[Action]) -> NoReturn:
    for i, action in enumerate(actions):
        print(f"{i+1} - {action.name}")

    action_id = int(input("action? ")) - 1
    if action_id < 0 or action_id >= len(actions):
        print("you can't")
        exit(1)

    exit(actions[action_id].handler())
