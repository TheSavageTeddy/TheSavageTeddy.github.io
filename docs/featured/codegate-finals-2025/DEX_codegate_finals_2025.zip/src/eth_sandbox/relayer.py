import json
import os
import time
from pathlib import Path
from threading import Thread, Timer, Event
from web3 import Web3
from web3.middleware import SignAndSendRawMiddlewareBuilder
from eth_sandbox.launcher import get_shared_secret
from eth_account import Account
from eth_abi import encode
import asyncio
from enum import Enum

HTTP_PORT = int(os.environ.get("HTTP_PORT", 8545))
CODE_CHAIN = 10
GATE_CHAIN = 100


LiquidityRequest = 0
LiquidityResponse = 1
SwapRequest = 2

def relay(node_id: str, stop_event: Event, node_info: list[dict]) -> None:
    
    ## check if the contract is deployed
    while True:
        if os.path.exists(f"/tmp/deploy-info/{node_id}") and os.path.getsize(f"/tmp/deploy-info/{node_id}") > 0:
            uuids = json.load(open(f"/tmp/deploy-info/{node_id}"))["uuids"]
            break
        else:
            continue
        time.sleep(0.5)
    
    code_deploy_info = json.load(open(f"/tmp/deploy-info/{uuids[0]}"))
    gate_deploy_info = json.load(open(f"/tmp/deploy-info/{uuids[1]}"))

    code_deployer_account = Account.from_mnemonic(
        code_deploy_info["mnemonic"],
        account_path="m/44'/60'/0'/0/0"
    )

    gate_deployer_account = Account.from_mnemonic(
        gate_deploy_info["mnemonic"],
        account_path="m/44'/60'/0'/0/0"
    )
    
    code_web3 = Web3(
        Web3.HTTPProvider(
            f"http://127.0.0.1:{HTTP_PORT}/{node_info[0]['uuid']}",
            request_kwargs={
                "headers": {
                    "Authorization": f"Bearer {get_shared_secret()}",
                    "Content-Type": "application/json",
                },
            },
        )
    )

    code_web3.middleware_onion.add(SignAndSendRawMiddlewareBuilder.build(code_deployer_account))
    code_web3.eth.default_account = code_deployer_account.address

    gate_web3 = Web3(
        Web3.HTTPProvider(
            f"http://127.0.0.1:{HTTP_PORT}/{node_info[1]['uuid']}",
            request_kwargs={
                "headers": {
                    "Authorization": f"Bearer {get_shared_secret()}",
                    "Content-Type": "application/json",
                },
            },
        )
    )

    gate_web3.middleware_onion.add(SignAndSendRawMiddlewareBuilder.build(gate_deployer_account))
    gate_web3.eth.default_account = gate_deployer_account.address

    ## get the contract addresses
    setup_abi = Path(f"/home/ctf/compiled/Setup.sol/Setup.json").read_text()
    setup_abi = json.loads(setup_abi)["abi"]
    code_setup_addr = code_deploy_info['address']
    code_setup_contract = code_web3.eth.contract(address=code_setup_addr, abi=setup_abi)
    
    gate_setup_addr = gate_deploy_info['address']
    gate_setup_contract = gate_web3.eth.contract(address=gate_setup_addr, abi=setup_abi)

    ## call "DEX" to get address of dex
    dex_abi = Path(f"/home/ctf/compiled/DEX.sol/DEX.json").read_text()
    dex_abi = json.loads(dex_abi)["abi"]
    code_dex_addr = code_setup_contract.functions.dex().call()
    code_dex_contract = code_web3.eth.contract(address=code_dex_addr, abi=dex_abi)

    gate_dex_addr = gate_setup_contract.functions.dex().call()
    gate_dex_contract = gate_web3.eth.contract(address=gate_dex_addr, abi=dex_abi)

    token_abi = Path(f"/home/ctf/compiled/Token.sol/Token.json").read_text()
    token_abi = json.loads(token_abi)["abi"]
    code_tokens = {}
    gate_tokens = {}
    code_tokens[Web3.keccak(b"USDC").hex()] = code_web3.eth.contract(address=code_setup_contract.functions.tokenA().call(), abi=token_abi)
    code_tokens[Web3.keccak(b"PURR").hex()] = code_web3.eth.contract(address=code_setup_contract.functions.tokenB().call(), abi=token_abi)
    code_tokens[Web3.keccak(b"MOODENG").hex()] = code_web3.eth.contract(address=code_setup_contract.functions.tokenC().call(), abi=token_abi)
    gate_tokens[Web3.keccak(b"USDC").hex()] = gate_web3.eth.contract(address=gate_setup_contract.functions.tokenA().call(), abi=token_abi)
    gate_tokens[Web3.keccak(b"PURR").hex()] = gate_web3.eth.contract(address=gate_setup_contract.functions.tokenB().call(), abi=token_abi)
    gate_tokens[Web3.keccak(b"MOODENG").hex()] = gate_web3.eth.contract(address=gate_setup_contract.functions.tokenC().call(), abi=token_abi)

    # Use asyncio for event listening
    async def listen_message_sent_async(src_contract, dst_contract, chain_id, tokens, stop_event):
        event_filter = src_contract.events.MessageSent.create_filter(from_block='latest')
        while not stop_event.is_set():
            events = event_filter.get_new_entries()
            if events:
                for event in events:
                    event_args = event['args']
                    event_message = event_args['message']
                    print(f"[{'CODE' if chain_id == CODE_CHAIN else 'GATE'} Chain] MessageSent: {event_message}")
                    print(event_message)
                    if event_message['messageType'] == LiquidityRequest:
                        tx_hash = tokens[event_message['dstToken'].hex()].functions.mint(event_message['receiver'], event_message['amount']).transact()
                    elif event_message['messageType'] == LiquidityResponse:
                        tx_hash = tokens[event_message['dstToken'].hex()].functions.burn(event_message['from'], event_message['amount']).transact()

                    message_tuple = (
                        event_message['messageType'],
                        event_message['from'],
                        event_message['receiver'],
                        event_message['srcToken'],
                        event_message['dstToken'],
                        event_message['srcChainId'],
                        event_message['dstChainId'],
                        event_message['amount'],
                    )
                    tx_hash = dst_contract.functions.handleMessage(message_tuple).transact()

            await asyncio.sleep(5)

    def run_asyncio_loop(loop, tasks):
        asyncio.set_event_loop(loop)
        loop.run_until_complete(asyncio.gather(*tasks))

    # Prepare wallet contracts and web3/admin for each chain


    loop = asyncio.new_event_loop()
    tasks = [
        listen_message_sent_async(code_dex_contract, gate_dex_contract, CODE_CHAIN, code_tokens, stop_event),
        listen_message_sent_async(gate_dex_contract, code_dex_contract, GATE_CHAIN, gate_tokens, stop_event)
    ]
    listener_thread = Thread(target=run_asyncio_loop, args=(loop, tasks))
    listener_thread.start()

    # Wait for stop_event to be set (relayer killed)
    while not stop_event.is_set():
        time.sleep(0.2)
    # After stop_event, stop asyncio loop
    loop.call_soon_threadsafe(loop.stop)
    listener_thread.join()


def start_relayer(node_id: str, node_info: list[dict], timeout: int) -> None:
    stop_event = Event()
    relayer = Thread(target=relay, args=(node_id, stop_event, node_info))
    relayer.start()

    def kill_relayer():
        stop_event.set()
        print("Relayer killed")
    
    timer = Timer(timeout, kill_relayer)
    timer.start() 